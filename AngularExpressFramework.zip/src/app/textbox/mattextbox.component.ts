import { Component, Input } from "@angular/core";
import { ControlBase } from '../baseComponents/controlBase';
import { ModelService } from '../services/modelService';

@Component({
    selector: 'mattextbox',
    templateUrl: 'mattextbox.component.html',
    styleUrls: ['mattextbox.component.scss'],
    host: {
        '[class]': 'widthClass()'
    }
})
export class MatTextBox extends ControlBase {
    id = 'testid'
    test: ModelService;

    constructor(private modelSvc: ModelService) {
        super();
        this.data = modelSvc.model;
    }
}