import { Component, ViewChild } from '@angular/core';
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { schema } from './schema';
 
@Component({
  selector: 'jsoneditor',
  templateUrl: 'jsoneditor.html',
})
export class JsonEditor {
    @ViewChild(JsonEditorComponent, {static:true}) editor: JsonEditorComponent;

    options = new JsonEditorOptions();
    data = {
      products: [{
        name: 'car',
        product: [{
          name: 'honda',
          model: [
            { id: 'civic', name: 'civic' },
            { id: 'accord', name: 'accord' },
            { id: 'crv', name: 'crv' },
            { id: 'pilot', name: 'pilot' },
            { id: 'odyssey', name: 'odyssey' }
          ]
        }]
      }]
    };
  constructor() {
    this.options.mode = 'code';
    //this.options.mainMenuBar = false;
    this.options.enableSort =false;
    this.options.enableTransform =false;
    this.options.modes = ['code', 'text'];
    this.options.schema = schema;
    this.options.statusBar = false;
    this.options.onChange = () => console.log(this.editor.get());

   
  }
 
}