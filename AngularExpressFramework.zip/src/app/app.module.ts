import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialModule } from './angular.material.module';
import { MatTextBox } from './textbox/mattextbox.component';
import { FormsModule } from '@angular/forms';
import { ExpressFrameworkComponent } from './expressFrameworkComponent/express.framework.component';
import { JsonEditor } from './jsoneditor/jsoneditor';
import { NgJsonEditorModule } from 'ang-jsoneditor';
import { AngularSplitModule } from 'angular-split'
import { Panel } from './panel/panel';
import { ModelService } from './services/modelService';
import { FormBuilderService } from './services/formBuilderService';
import { EfSplitComponent } from './split/split';

@NgModule({
  declarations: [
    AppComponent,
    Panel,
    MatTextBox,
    ExpressFrameworkComponent,
    JsonEditor,
    EfSplitComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    FormsModule,
    NgJsonEditorModule,
    AngularSplitModule
  ],
  providers: [ModelService, FormBuilderService],
  bootstrap: [AppComponent],
  entryComponents: [MatTextBox, Panel, EfSplitComponent]
})
export class AppModule { }
