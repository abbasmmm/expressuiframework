import { NgModule } from '@angular/core';
import {
    MatAutocompleteModule,
    MatInputModule,
    MatButtonModule
} from '@angular/material';

@NgModule({
    imports: [MatAutocompleteModule,MatInputModule, MatButtonModule],
    exports: [MatAutocompleteModule,MatInputModule, MatButtonModule]
})

export class AngularMaterialModule { }