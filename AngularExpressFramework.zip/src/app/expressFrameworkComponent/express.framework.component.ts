import { Component, ComponentFactoryResolver, ComponentRef, ViewChild, ViewContainerRef } from "@angular/core";
import { ContainerBase } from '../baseComponents/containerBase';
import { resolve } from 'url';
import { Panel } from '../panel/panel';
import { MatTextBox } from '../textbox/mattextbox.component';
import { ModelService } from '../services/modelService';
import { FormBuilderService } from '../services/formBuilderService';

@Component({
    selector: 'express-framework',
    templateUrl: './express.framework.component.html'
})
export class ExpressFrameworkComponent extends ContainerBase {
    test: ModelService;

    constructor(private resolver: ComponentFactoryResolver, private modelSvc: ModelService, private formBuilderService: FormBuilderService) {
        super();
        this.factoryResolver = resolver;
        this.childRules = rules[0].rules;
        this.createChildren = this.formBuilderService.createChildren;
    }

    getData() {
        return JSON.stringify(this.modelSvc.model);
    }
}

const rules =
    [{
        product: "irs",
        layout: "plain",
        rules: [
            {
                type: 'efsplit',
                children: [
                    {
                        type: 'panel',
                        columns: 3,
                        children: [
                            {
                                type: 'mattextbox',
                                name: 'firstName',
                                label: 'First Name',
                                model: 'root.firstName'
                            },
                            {
                                type: 'mattextbox',
                                name: 'lastName',
                                label: 'Last Name',
                                model: 'root.lastName'
                            },
                            {
                                type: 'mattextbox',
                                name: 'firstName',
                                label: 'First Name',
                                model: 'root.firstName'
                            },
                            {
                                type: 'mattextbox',
                                name: 'lastName',
                                label: 'Last Name',
                                model: 'root.lastName'
                            }
                        ]                        
                    },
                    {
                        type: 'panel',
                        children: [                            
                            {
                                type: 'panel',
                                columns: 2,
                                children: [
                                    {
                                        type: 'mattextbox',
                                        name: 'address',
                                        label: 'Address',
                                        model: 'root.address.address'
                                    },
                                    {
                                        type: 'mattextbox',
                                        name: 'city',
                                        label: 'city',
                                        model: 'root.address.city'
                                    },
                                    {
                                        type: 'mattextbox',
                                        name: 'pin',
                                        label: 'pin',
                                        model: 'root.address.pin'
                                    },
                                ]                        
                            }
                        ]                        
                    }
                ]
            }
        ]
    }];