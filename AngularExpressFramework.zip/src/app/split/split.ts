import { Component, ComponentFactoryResolver, ViewContainerRef, ViewChild } from "@angular/core";
import { ContainerBase } from '../baseComponents/containerBase';

@Component({
    selector:'ef-split',
    templateUrl: 'split.html'
})
export class EfSplitComponent extends ContainerBase
{
    @ViewChild('container1', { static: false, read: ViewContainerRef }) container1: ViewContainerRef;
    @ViewChild('container2', { static: false, read: ViewContainerRef }) container2: ViewContainerRef;

    constructor(private resolver: ComponentFactoryResolver)
    {
        super();
        this.factoryResolver = resolver;        
    }    

    ngAfterViewInit(){
        if (!!this.createChildren)
        {
            debugger;
            this.createChildren([this.childRules[0]], this.container1, this.factoryResolver, this.componentRefs, this.rule);
            this.createChildren([this.childRules[1]], this.container2, this.factoryResolver, this.componentRefs, this.rule);
        }
    }
}