import { Component, ViewContainerRef, ViewChild, ComponentFactoryResolver, Type } from "@angular/core";


@Component({
    selector:'test',
    templateUrl :'test.html'
})
export class TestComponent{
    @ViewChild('container', {read: ViewContainerRef, static:true}) container: ViewContainerRef;

    // Keep track of list of generated components for removal purposes
    components = [];
  
    constructor(private componentFactoryResolver: ComponentFactoryResolver) {
    }

    ngAfterViewInit()
    {        
        //this.addComponent()
    }
  
    addComponent(componentClass: Type<any>) {
      // Create component dynamically inside the ng-template
      const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);
      const component = this.container.createComponent(componentFactory);
  
      // Push the component so that we can keep track of which components are created
      this.components.push(component);
    }
  
    removeComponent(componentClass: Type<any>) {
      // Find the component
      const component = this.components.find((component) => component.instance instanceof componentClass);
      const componentIndex = this.components.indexOf(component);
  
      if (componentIndex !== -1) {
        // Remove component from both view and array
        this.container.remove(this.container.indexOf(component));
        this.components.splice(componentIndex, 1);
      }
    }
}