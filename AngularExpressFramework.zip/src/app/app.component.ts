import {
  Component,
  ViewChild,
  ViewContainerRef,
  ComponentFactoryResolver,
  ComponentRef,
  ComponentFactory
} from '@angular/core';
import { MatTextBox } from './textbox/mattextbox.component';
import { ControlBase } from './baseComponents/controlBase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'AngularExpressFramework';
  data = {
    text: 'this is data',
  };

  rule = {
    visible: "1==1",
    required: "true",
    bindingExpr: 'root.text'
  }



  ngAfterViewInit() {
    console.log('after viewinit')
    //this.createComponent(MatTextBox);
    
  }



  change(){
    this.data.text = "kyu k mai chutiya hu"
  }
}
