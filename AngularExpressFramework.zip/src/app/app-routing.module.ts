import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExpressFrameworkComponent } from './expressFrameworkComponent/express.framework.component';
import { JsonEditor } from './jsoneditor/jsoneditor';

const routes: Routes = [
  { path: '', component: ExpressFrameworkComponent },
  { path: 'jsoneditor', component: JsonEditor }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
