import { ComponentFactoryResolver, ViewChild, ViewContainerRef, ComponentRef } from '@angular/core';
import { typeInfo } from '../services/typeResolutionService';
import { ControlBase } from './controlBase';

export class ContainerBase extends ControlBase {
    componentRefs: ComponentRef<any>[] = [];
    childRules: any[];
    factoryResolver: ComponentFactoryResolver;
    createChildren;

    @ViewChild('container', { static: false, read: ViewContainerRef }) entry: ViewContainerRef;

    ngOnDestroy() {
        this.componentRefs.forEach(element => {
            element.destroy();
        });
    }

    ngAfterViewInit() {
        if (!!this.createChildren)
            this.createChildren(this.childRules, this.entry, this.factoryResolver, this.componentRefs, this.rule);
    }
}