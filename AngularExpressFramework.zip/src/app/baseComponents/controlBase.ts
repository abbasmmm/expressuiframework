import { Input } from '@angular/core';
import { ModelService } from '../services/modelService';

export class ControlBase {
    @Input()
    data: any

    @Input()
    rule: any

    columns: number=1;

    // constructor(private modelService: ModelService)
    // {

    //     //this.data = modelService.model;
    // }

    get visible() {
        if (!!this.rule) {
            return new Function('root', 'return ' + this.rule.visible)(this.data);
        }
    }

    get model() {
        return this.getNullSafeFromExpression();
        // return new Function('root', 'return ' + this.rule.model)(this.data);
    }

    set model(value) {
        new Function('root', 'value', this.rule.model + ' = value')(this.data, value);
    }

    ngAfterViewInit() {
        console.log('ngAfterViewInit');
    }

    widthClass() {
        
        return "col-" + 12 / this.columns;
    }

    getNullSafeFromExpression()
    {
        let path =this.rule.model.split('.');
        let propName = path[path.length-1];
        let curData = this.data;
        for (let index = 1; index < path.length-1; index++) {
            const curProperty = path[index];
            
            if(!curData[curProperty])
            {
                curData[curProperty] ={};
            }

            curData = curData[curProperty];
        }

        return curData[propName];
    }
}