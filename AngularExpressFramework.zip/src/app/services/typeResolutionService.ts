import { MatTextBox } from "../textbox/mattextbox.component";
import { Panel } from '../panel/panel';
import { EfSplitComponent } from '../split/split';

export const typeInfo = {
  'mattextbox': MatTextBox,
  'panel': Panel,
  'efsplit': EfSplitComponent
}