import { Injectable, ViewContainerRef, ComponentFactoryResolver, ComponentRef } from '@angular/core';
import { typeInfo } from './typeResolutionService';

@Injectable({
  providedIn: 'root',
})
export class FormBuilderService {
  createChildren(childRules: any[], entry: ViewContainerRef, factoryResolver: ComponentFactoryResolver, componentRefs: ComponentRef<any>[], parentRule: any) {
    for (let index = 0; index < childRules.length; index++) {
      const rule = childRules[index];

      const factory = factoryResolver.resolveComponentFactory(typeInfo[rule.type] as any);
      let ref: ComponentRef<any> = entry.createComponent(factory) as any;

      if (!!rule.children) {
        ref.instance.childRules = rule.children;
        ref.instance.createChildren = this.createChildren;
      }

      ref.instance.rule = rule;

      if (!!parentRule)
        ref.instance.columns = parentRule.columns;
      
        if(!ref.instance.columns )
        ref.instance.columns = 1;

      ref.changeDetectorRef.detectChanges();
      componentRefs.push(ref);
    }
  }
}