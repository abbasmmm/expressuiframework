import { ComponentFactoryResolver, ViewChild, ViewContainerRef, ComponentRef, Component } from '@angular/core';
import { ModelService } from '../services/modelService';
import { ContainerBase } from '../baseComponents/containerBase';

@Component({
    selector:'panel',
    templateUrl : 'panel.html',
    host:
    {
        '[class]':'widthClass()'
    }
})
export class Panel extends ContainerBase
{
    constructor(private resolver: ComponentFactoryResolver, private modelSvc : ModelService)
    {
        super();
        this.factoryResolver = resolver;        
    }    
}